import java.sql.*;


class  preparedstatement
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }


             //create query
			 String q = "INSERT INTO TABLE1(NAME,CITY) VALUE (?, ?)";
			 PreparedStatement psmt = con.prepareStatement(q);
              psmt.setString(1,"didu");
			  psmt.setString(2,"pune");

			  psmt.executeUpdate();
			  System.out.println("Values Inserted........................");
			  con.close();

	            /* Special Notes Binding Parameters:
		        The setString(int parameterIndex, String x) method binds the values to the placeholders in the prepared statement.
		        parameterIndex is 1-based, meaning:
		        setString(1, "light") binds the first placeholder (?) to the string "light" for the NAME column.
		        setString(2, "Thane") binds the second placeholder (?) to the string "Thane" for the CITY column. 
				*/

				/*in sql

				-- Prepare the SQL statement
                PREPARE stmt FROM 'SELECT * FROM users WHERE username = ? AND password = ?';

                -- Bind parameters
                   SET @username = 'user1';
                 SET @password = 'password123';

                 -- Execute the prepared statement
                 EXECUTE stmt USING @username, @password;

               -- Deallocate the prepared statement when done
                  DEALLOCATE PREPARE stmt;

				
				
				
				
				
				
				*/








           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
