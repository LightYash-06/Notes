import java.sql.*;


class  selectjdbc
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }


               String q = "select * from table1";
               Statement stmt = con.createStatement();

               ResultSet set = stmt.executeQuery(q);

			   while(set.next())
			   {
				  int id = set.getInt(1);
				  String name = set.getString(2);
				  String city = set.getString(3);

				  System.out.println(id + "  "  + name+ "  " + city +"  ");







			   }




           System.out.println(".....................Shown all the data successfully......................");

           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
