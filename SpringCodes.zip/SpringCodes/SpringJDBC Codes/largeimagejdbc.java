import java.sql.*;
import java.io.*;
import javax.swing.*;

class  largeimagejdbc
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }
              String q = "insert into cricketers(pic) values(?)";

             PreparedStatement psmt = con.prepareStatement(q);
			 JFileChooser jfc = new JFileChooser();
			 jfc.showOpenDialog(null);
			 File file = jfc.getSelectedFile();
			 FileInputStream fis = new FileInputStream(file);
			 psmt.setBinaryStream(1,fis,fis.available());
			 psmt.executeUpdate();
			 JOptionPane.showMessageDialog(null,"Image added into database successfully");
			  System.out.println("Image added into database successfully");









           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
