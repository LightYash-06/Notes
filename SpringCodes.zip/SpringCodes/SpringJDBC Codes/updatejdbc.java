import java.sql.*;
import java.util.*;

class  updatejdbc
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }


			   String q = "update table1 set name=? , city=? where id=?"; 

             Scanner scn = new Scanner(System.in);
			 System.out.println("Enter Name :");
			 String name = scn.nextLine();

			 System.out.println("Enter city :");
			 String city = scn.nextLine();

			 System.out.println("Enter ID :");
			 int id = scn.nextInt();

             PreparedStatement psmt = con.prepareStatement(q);

			 psmt.setString(1,name);
			  psmt.setString(2,city);
			  psmt.setInt(3,id);

			   psmt.executeUpdate();
			   System.out.println(".........................Table Updated Successfully........................");
			  con.close();
              scn.close();








           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
