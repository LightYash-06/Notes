import java.sql.*;
import java.util.*;
import java.io.*;

class  firstjdbc
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }

            
              
             //create query
			 String q = "INSERT INTO TABLE1(NAME,CITY) VALUE (?, ?)";
			 PreparedStatement psmt = con.prepareStatement(q);





			 Scanner scn = new Scanner(System.in);
			 System.out.println("Enter Name :");
			 String name = scn.nextLine();

			 System.out.println("Enter your city :");
			 String city = scn.nextLine();




              psmt.setString(1,name);
			  psmt.setString(2,city);

			  psmt.executeUpdate();
			  System.out.println("Values Inserted........................");
			  con.close();
              scn.close();







           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
