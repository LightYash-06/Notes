import java.sql.*;


class  firstjdbc
{
	public static void main(String[] args) 
	{
           try
           {
			//Load the Driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			//Creating a connection url username and passowrd in string
             String url = "jdbc:mysql://localhost:3306/timrpass";
			 String username = "root";
			 String password = "light";
			Connection con = DriverManager.getConnection(url,username,password);


            //checking for connection for our understanding
			if(con.isClosed())
			   {
				System.out.println("Connection is closed");
			   }else
			   {
				System.out.println("Connection is created");
			   }











           }
           catch (Exception e)
           {
			   e.printStackTrace();
           }












	}
}
